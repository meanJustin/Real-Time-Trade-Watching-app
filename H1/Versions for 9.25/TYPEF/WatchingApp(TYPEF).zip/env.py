
#assign the source filepath
FILEPATH = "C:\\Users\\VMAK CAPITAL\\AppData\\Roaming\\MetaQuotes\\Terminal\\CEA95A93FC8D185DD2235895C53A5FFF\\MQL4\\Files\\"
#FILEPATH = ".\\Assets\\"

#assign the mastersheet filepath
MASTERFILEPATH = ".\\Assets\\"

#the measure is second
CYCLE_TIME = 60 * 60

#the period of refresh or should I say update?
REFRESH_TIME = 5

#TYPEFMASTERSHEET.xlsx file name
TYPEF_MASTER = "MasterTypeFSheet.xlsx"

#out put file names
#TYPEF PRINT
TYPEF_PRINT = "TypeF.csv"
